/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

class Apples {
  public:
    int apple;
    int apples () {
      cin >> apple;
      cout << "Number of Apples :" << apple << endl;
      return apple;}};
class Mangos {
  public:
    int mango;
    int mangos () {
      cin >> mango;
      cout << "Number of Mangos :" << mango << endl;
      return mango;}};
class Fruits : public Apples,public Mangos{
  public:
   void cal (int a,int b) {
     cout << "Total Number of Fruits :" << a+b << endl;}};
int main() 
{
    Fruits obj;
    obj.apples();
    obj.mangos();
    int a = obj.apple;
    int b = obj.mango;
    obj.cal(a,b);
    return 0;
}
