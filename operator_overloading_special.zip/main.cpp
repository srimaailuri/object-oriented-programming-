/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
class Marks{
    int subjects[3];
    public:
    Marks(int sub1,int sub2,int sub3){
        subjects[0]=sub1;
        subjects[1]=sub2;
        subjects[2]=sub3;
    }
    int operator[](int position){
        return subjects[position];
    }
};
int main()
{
    Marks st1(22,33,55);
    cout<<st1[0]<<endl;
    cout<<st1[1]<<endl;
    cout<<st1[2]<<endl;
    return 0;
}