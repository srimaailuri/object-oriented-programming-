/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
class Bank{
    public:
    int getBalance(){
        return 0;
    }
};
class BankA:public Bank{
    public:
    int Balance=1000;
    int getBalance(){
        cout<<"balance is :"<<Balance<<endl;
    }
};
class BankB:public Bank{
    public:
    int Balance=1500;
    int getBalance(){
        cout<<"balance is :"<<Balance<<endl;
    }
};
class BankC:public Bank{
    public:
    int Balance=2000;
    int getBalance(){
        cout<<"balance is :"<<Balance<<endl;
    }
};
int main()
{
    Bank obj1;
    obj1.getBalance();
    BankA A;
    A.getBalance();
    BankB B;
    B.getBalance();
    BankC C;
    C.getBalance();
    return 0;
}
