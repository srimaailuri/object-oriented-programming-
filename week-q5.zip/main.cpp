/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
class Degree{
    public:
    void getDegree(){
        cout<<"I got a degree"<<endl;
    }
};
class undergraduate:public Degree{
    public:
    void Undergraduate(){
        cout<<"I am an undergraduate"<<endl;
    }
};
class postgraduate:public Degree{
    public:
    void Postgraduate(){
        cout<<"I am an Postgraduate"<<endl;
    }
};
int main()
{
    undergraduate p1;
    p1.Undergraduate();
    postgraduate p2;
    p2.Postgraduate();
    Degree p3;
    p3.getDegree();

    return 0;
}