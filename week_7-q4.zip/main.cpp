/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
class Base{
public:
      int id_no;
      float salary;
      void getdata(int number,float emp_salary){
          id_no=number;
          salary=emp_salary;
      }
};
class bonus:public Base{
public:
      float bonus;
      void bonus_salary(float bonus_sal){
          bonus=bonus_sal;
          salary=salary+bonus;
          cout<<"total salary after adding bonus:"<<salary<<endl;
      }
};
class derived:public Base{
public:
      void printdata(){
          cout<<"Id number:"<<id_no<<endl;
          cout<<"salary before incrementing bonus:"<<salary<<endl;
      }
};

int main()
{
    derived emp1;
    emp1.getdata(225,95000);
    emp1.printdata();
    bonus emp2;
    emp2.getdata(1,95000);
    emp2.bonus_salary(5000);
    

    return 0;
}
