/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
using namespace std;
class AddAmount{
    public:
    int amount =50;
    AddAmount(){
        cout<<"Initial amount:"<<amount;
    }
    AddAmount(int deposited){
        amount=amount+deposited;
        cout<<"Total amount is:"<<amount;
    }  
};
int main()
{
    
    AddAmount person1(20);
   

    return 0;
}
