/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
class sum{
    public:
    int sum;
    void find_sum(int a,int b){
        sum=a+b;
        cout<<"sum is :"<<sum<<endl;
    }
    void find_sum(int a,int b,int c){
        sum=a+b+c;
        cout<<"sum is :"<<sum<<endl;
    }
    void find_sum(double a,double b){
        sum=a+b;
        cout<<"sum is :"<<sum;
    }
};
int main()
{
    sum obj,obj1,obj2;
    obj.find_sum(4,2);
    obj1.find_sum(2,5,3);
    obj2.find_sum(2.6,3.5);
    

    return 0;
}