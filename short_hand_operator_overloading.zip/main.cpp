/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
class Marks{
    int mark;
    public:
      Marks(){
          mark=0;
      }
      Marks(int m){
          mark=m;
      }
      void yourmarkplease(){
          cout<<"your mark is:"<<mark<<endl;
      }
      void operator +=(int bonusmark){
          mark+=bonusmark;
      }
      friend void operator -=(Marks &curobj,int redmark);
};
void operator -=(Marks &curobj,int redmark){
    curobj.mark-=redmark;
}
int main()
{
    Marks mymark(45);
    mymark.yourmarkplease();
    mymark+=20;
    mymark.yourmarkplease();
    mymark-=20;
    mymark.yourmarkplease();
    return 0;
}
