/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
class Base1{
public:
      int regno;
      float marks;
      void getdata(int number,float sub_marks){
          regno=number;
          marks=sub_marks;
      }
};
class Base2{
public:
      string studentname;
      void getstring(string name){
          studentname=name;
      }
};
class derived:public Base1,public Base2{
public:
    void printdata(){
        cout<<"register number:"<<regno<<endl;
        cout<<"Marks:"<<marks<<endl;
        cout<<"student name:"<<studentname<<endl;
    }
};
int main()
{
    derived st1;
    st1.getdata(225,96.5);
    st1.getstring("srima");
    st1.printdata();

    return 0;
}