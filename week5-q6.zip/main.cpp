/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
class swapo{
    public:
    int c,d;
    void swap_num(int a, int b){
        c=a;
        d=b;
        cout<<"before Swaping: "<<c<<" "<<d<<endl;
       swap(c,d);
        }
        void swap_num()
        {
            cout<<"After Swapping: "<<c<<" "<<d;
            }
        
    };
int main()
{
    swapo obj1,obj2;
    obj1.swap_num(2,3);
    obj1.swap_num();
    return 0;
}
