/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
class Base1{
public:
      int regno;
      string student_name;
      void getdata(string name,int number){
          student_name=name;
          regno=number;
      }
};
class Base2{
public:
      float marks[5];
      void getmarks(float sub1,float sub2,float sub3,float sub4,float sub5){
          marks[0]=sub1;
          marks[1]=sub2;
          marks[2]=sub3;
          marks[3]=sub4;
          marks[4]=sub5;
      }
};
class derived:public Base1,public Base2{
public:
    void printdata(){
        cout<<"\t"<<"student name:"<<"\t"<<"id no.:"<<endl;
        cout<<"\t"<<student_name<<"\t"<<regno<<endl;
        cout <<"marks of "<<student_name<<endl;
        cout<<"sub1"<<marks[0];
        cout<<"sub2"<<marks[1];
        cout<<"sub3"<<marks[2];
        cout<<"sub4"<<marks[3];
        cout<<"sub5"<<marks[4];
    }
};
int main()
{
    derived st1;
    st1.getdata("srima",225);
    st1.getmarks(89,96,96,95,95);
    st1.printdata();

    return 0;
}


