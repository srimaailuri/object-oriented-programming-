/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

class volume{
    public: 
    int volume;
    void find_vol(int s){
        volume=s*s*s;
        cout<<"volume of cube:"<<volume<<endl;
    }
    void find_vol(double radius){
        volume=(4*3.14*radius*radius*radius)/3;
        cout<<"volume of sphere:"<<volume<<endl;
    }
    void find_vol(int radius,int height){
        volume=(3.14*radius*radius*height);
        cout<<"volume of cylinder:"<<volume;
    }
    
};

int main()
{
    volume cube,cylinder,sphere;
    cube.find_vol(5);
    cylinder.find_vol(5.0);
    sphere.find_vol(2,3);
    return 0;
}