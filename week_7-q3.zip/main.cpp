/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
class number{
    public:
    int num;
    void getdata(){
        cout<<"give number:";
        cin>>num;
    }
};
class square:public number{
    public:
    void square_num(){
    cout<<"square of a number :"<<num*num<<endl;}
};
class cube:public number{
    public:
    void cube_num(){
    cout<<"cube of a number :"<<num*num*num<<endl;}
};
int main()
{
    
    square n1;
    n1.getdata();
    n1.square_num();
    cube n2;
    n2.getdata();
    n2.cube_num();
    
   

    return 0;
}