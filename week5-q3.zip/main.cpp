/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
using namespace std;
class area{
    public: 
    int area;
    int l,b;
    void find_area(int s){
        area=s*s;
        cout<<"area of square:"<<area<<endl;
    }
    void find_area(int length,int breadth){
        l=length;
        b=breadth;
        area=length*breadth;
        cout<<"area of rectangle:"<<area;
    }
};

int main()
{
    area square;
    area rectangle;
    square.find_area(5);
    rectangle.find_area(4,5);
    return 0;
}
