/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
class Base1{
public:
      int l;
      void getlen(){
      cout<<"enter length:";
      cin>>l;}
};
class Base2{
public:
      int b,h;
      void getbh(){
      cout<<"enter breadth and height:";
      cin>>b>>h;}
};
class derived:public Base1,public Base2{
public:
    void printdata(){
        cout<<"Area:"<<l*b<<endl;
        cout<<"volume"<<l*b*h<<endl;
    }
};
int main()
{
    derived s1;
    s1.getlen();
    s1.getbh();
    s1.printdata();

    return 0;
}
