/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
class Base{
public:
      int regno;
      float marks;
      string studentname;
      void getdata(int number,float sub_marks,string name){
          regno=number;
          marks=sub_marks;
          studentname=name;
      }
};
class derived:public Base{
    public:
    void printdata(){
        cout<<"register number:"<<regno<<endl;
        cout<<"Marks:"<<marks<<endl;
        cout<<"student name:"<<studentname<<endl;
    }
};
int main()
{
    derived st1;
    st1.getdata(225,96.5,"srima");
    st1.printdata();

    return 0;
}