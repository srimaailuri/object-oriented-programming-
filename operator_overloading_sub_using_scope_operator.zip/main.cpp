/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
class Marks{
    int intmark;
    int extmark;
    
    public:
      Marks(){
          intmark=0;
          extmark=0;
      }
      Marks(int im,int em){
          intmark=im;
          extmark=em;
      }
      void display(){
          cout<<intmark<<endl<<extmark<<endl;
      }
      Marks operator -(Marks m);
};
 Marks Marks:: operator -(Marks m){
          Marks temp;
          temp.intmark=intmark-m.intmark;
          temp.extmark=extmark-m.extmark;
          return temp;
      }
int main()
{
    Marks m1(10,20),m2(30,40);
    Marks m3=m2-m1;
    m3.display();

    return 0;
}
